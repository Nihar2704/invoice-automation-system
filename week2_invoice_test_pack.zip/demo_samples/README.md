# Week 2 Invoice PDF Test Pack

This folder contains synthetic PDF invoices for testing the Week 2 OCR and extraction pipeline of the Smart Invoice Automation System.

## What to test

1. PDF text extraction using pdfplumber or PyMuPDF.
2. Image-only scanned PDF OCR using Tesseract or EasyOCR.
3. File type detection.
4. Raw text extraction.
5. Text cleaning and line splitting.
6. ML line classification.
7. Field extraction for invoice_id, vendor_name, invoice_date, due_date, total_amount, tax_amount, GSTIN.
8. Duplicate detection using same vendor + same invoice_id + same amount.

## Files

- invoice_01_text_standard.pdf: clean text-based baseline invoice.
- invoice_02_text_modern.pdf: different wording such as Supplier, Issued On, Pay Before, Total Payable.
- invoice_03_text_compact.pdf: compact bill layout with short date format.
- invoice_04_text_tax_invoice.pdf: CGST + SGST split.
- invoice_05_text_missing_due_date.pdf: missing due date; should be marked review/missing.
- invoice_06_text_duplicate_of_01.pdf: duplicate of invoice_01 by vendor + invoice_id + amount.
- invoice_07_scanned_clean.pdf: image-only scanned PDF for OCR testing.
- invoice_08_scanned_ocr_noise.pdf: image-only PDF with deliberate OCR-like mistakes such as 1NV, Rs,, and O in amount.
- invoice_09_scanned_rotated.pdf: image-only PDF with slight rotation.
- invoice_10_text_multipage.pdf: two-page text PDF; main fields on page 1.

## Expected outputs

See `sample_outputs/ground_truth.csv` and `sample_outputs/ground_truth.json` in the zip.

## Suggested project location

Place the PDFs inside:

```text
invoice-automation-system/demo_samples/
```

Place the expected output files inside:

```text
invoice-automation-system/data/sample_outputs/
```
